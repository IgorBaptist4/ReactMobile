
ultilizamos o wampserver para rodar o servidor local, 
criamos o banco "reactbugs" e a tabela funcionários
testamos o servidor local e estava funcionando, assim como na porta "localhost:3000"
entretando ao iniciar a aplicação a mesma dava erro de incompatibilidade com o grandle. 

devido ao curto prazo, não conseguimos solucionar o problema antes fazer o envio do trabalho.  